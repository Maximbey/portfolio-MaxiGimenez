function move1() {
    var elem = document.getElementById("myBar1");
    var width=100;
     elem.style.width = (width-10) + '%';
        
    
}

